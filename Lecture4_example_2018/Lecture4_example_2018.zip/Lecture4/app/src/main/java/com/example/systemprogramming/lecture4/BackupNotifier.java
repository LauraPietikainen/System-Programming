package com.example.systemprogramming.lecture4;

public interface BackupNotifier {
    void backupNow();
}
